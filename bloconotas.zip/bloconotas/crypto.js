// Criptografia do cofre (WebCrypto). Nada sai do aparelho em texto legível.
const te = new TextEncoder();
const td = new TextDecoder();

export const toB64 = (buf) => {
  const b = new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode(...b.subarray(i, i + 0x8000));
  return btoa(s);
};
export const fromB64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const rnd = (n) => crypto.getRandomValues(new Uint8Array(n));

export const PW_ITER = 600000;
export const RK_ITER = 100000;

async function kek(secret, salt, iterations) {
  const base = await crypto.subtle.importKey('raw', te.encode(secret), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
    base,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}
async function wrap(raw, secret, iterations) {
  const salt = rnd(16);
  const iv = rnd(12);
  const k = await kek(secret, salt, iterations);
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, k, raw);
  return { salt: toB64(salt), iv: toB64(iv), ct: toB64(ct) };
}
async function unwrap(slot, secret, iterations) {
  const k = await kek(secret, fromB64(slot.salt), iterations);
  return crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(slot.iv) }, k, fromB64(slot.ct));
}
const importDK = (raw) => crypto.subtle.importKey('raw', raw, 'AES-GCM', true, ['encrypt', 'decrypt']);

const ALPHA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function b32(bytes) {
  let bits = 0, val = 0, out = '';
  for (const b of bytes) {
    val = (val << 8) | b;
    bits += 8;
    while (bits >= 5) {
      out += ALPHA[(val >>> (bits - 5)) & 31];
      bits -= 5;
    }
    val &= (1 << bits) - 1;
  }
  return out;
}
export const fmtRK = (s) => s.match(/.{4}/g).join('-');
export const normRK = (s) => String(s).toUpperCase().replace(/[^A-Z2-7]/g, '');

// Cria um cofre novo: uma chave de dados aleatória, protegida pela senha e pela chave de recuperação.
export async function createVault(password) {
  const raw = rnd(32);
  const rk = b32(rnd(20));
  const vault = {
    v: 1,
    pwIter: PW_ITER,
    rkIter: RK_ITER,
    pw: await wrap(raw, password, PW_ITER),
    rk: await wrap(raw, rk, RK_ITER),
    created: Date.now()
  };
  return { vault, DK: await importDK(raw), recovery: fmtRK(rk) };
}
export async function unlockWithPassword(vault, password) {
  return importDK(await unwrap(vault.pw, password, vault.pwIter));
}
export async function unlockWithRecovery(vault, recovery) {
  return importDK(await unwrap(vault.rk, normRK(recovery), vault.rkIter));
}
export async function rewrapPassword(vault, DK, newPassword) {
  const raw = await crypto.subtle.exportKey('raw', DK);
  return { ...vault, pw: await wrap(raw, newPassword, vault.pwIter) };
}
export async function newRecoveryKey(vault, DK) {
  const raw = await crypto.subtle.exportKey('raw', DK);
  const rk = b32(rnd(20));
  return { vault: { ...vault, rk: await wrap(raw, rk, vault.rkIter) }, recovery: fmtRK(rk) };
}
export async function encryptJSON(DK, obj) {
  const iv = rnd(12);
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, DK, te.encode(JSON.stringify(obj)));
  return { iv: toB64(iv), ct: toB64(ct) };
}
export async function decryptJSON(DK, rec) {
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(rec.iv) }, DK, fromB64(rec.ct));
  return JSON.parse(td.decode(pt));
}
