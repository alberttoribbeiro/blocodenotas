# BlocoNotas — etapa 1 (cofre local)

App de notas que roda no navegador e pode ser instalado no celular e no desktop.
Nesta etapa tudo fica **neste aparelho**, criptografado. A sincronização (GitHub) e o assistente com IA são as etapas 2 e 3.

## O que já funciona
- Cofre com senha mestra e chave de recuperação (AES-256-GCM, chave derivada com PBKDF2).
- Notas com título, texto, área (13), etiquetas (27), fixar, arquivar e excluir.
- Busca por texto, #etiqueta ou área, e filtros pela lateral.
- Assistente por comandos em português (criar, mover, etiquetar, arquivar, buscar, visão geral).
- Trancamento automático, troca de senha, nova chave de recuperação, backup criptografado.
- Funciona offline depois do primeiro acesso e se adapta a celular e desktop.

## Como publicar (grátis, no GitHub Pages)
1. No GitHub, crie um repositório **público** chamado `bloconotas` (só o código do app, sem segredos).
2. Envie todos os arquivos desta pasta para a raiz do repositório.
3. Em Settings > Pages, escolha "Deploy from a branch", branch `main`, pasta `/ (root)`.
4. Abra o endereço `https://SEU-USUARIO.github.io/bloconotas/`.
5. No celular: abra o endereço no navegador e use "Adicionar à tela inicial". No desktop (Chrome ou Edge): ícone de instalar na barra de endereço.

Para testar antes, dentro desta pasta: `python3 -m http.server 8000` e abra `http://localhost:8000`.

## Avisos importantes
- Cada aparelho guarda suas próprias notas até a etapa 2. Para levar o cofre a outro aparelho agora, use "Exportar cópia criptografada" nas Configurações e, no outro aparelho, "Já tenho uma cópia do cofre" na criação.
- Se você esquecer a senha **e** perder a chave de recuperação, as notas não podem ser recuperadas por ninguém.
- Limpar os dados do navegador apaga o cofre daquele aparelho. Faça backups.
- Ainda não há desbloqueio por biometria; fica para uma etapa seguinte.
- Esta etapa foi testada em navegador automatizado (criar cofre, desbloquear, notas, recuperação, celular). Não passou por auditoria de segurança externa.
