import * as C from './crypto.js';

/* ============ dados fixos ============ */
const AREAS = [
  ['1', 'Espiritual / Propósito', '#2F6DB5'], ['2', 'Profissional / Carreira', '#8B4FC4'],
  ['3', 'Financeiro / Negócios', '#2E9E5B'], ['4', 'Sentimental / Relacionamentos', '#D64545'],
  ['5', 'Saúde / Bem-estar / Fitness', '#C9A21C'], ['6', 'Família / Amigos / Network', '#E0832B'],
  ['7', 'Mentalidade / Intelectual', '#8A6A4A'], ['8', 'Estudos / Cursos', '#2F6DB5'],
  ['9', 'Hobbies / Lazer / Leitura', '#8B4FC4'], ['10', 'Metas / Sonhos', '#2E9E5B'],
  ['11', 'Ambiente / Organização', '#D64545'], ['12', 'Tecnologia / Sistemas', '#C9A21C'],
  ['13', 'Autoimagem / Estilo', '#E0832B']
].map(([id, name, color]) => ({ id, name, color }));

const TAGS = [
  ['Working', '#5E9E1F'], ['Waiting', '#D6336C'], ['Personnalité', '#1C8FBF'], ['Enterprises', '#D64545'],
  ['Calendar', '#2F5FD0'], ['Deskmart', '#1FA08A'], ['Home', '#17798C'], ['Street', '#6B7A90'],
  ['05 Minutos', '#C76B8F'], ['15 Minutos', '#D6458F'], ['30 Minutos', '#A22FC4'], ['60 Minutos', '#D6336C'],
  ['300 Minutos', '#C62F2F'], ['SubGrupo', '#A68A0A'], ['Network', '#C75F9A'], ['Planner', '#D6336C'],
  ['Finance', '#8B2FC4'], ['Compras', '#A68A0A'], ['Store', '#D9731A'], ['Mindset', '#7C9A1F'],
  ['Care', '#D9705A'], ['LowTicket', '#5B3FC4'], ['Manutenção', '#7A6F66'], ['Flix', '#8CA314'],
  ['Fit', '#5E9E1F'], ['Recorrente', '#2E7D1F'], ['Someday', '#7A6F66']
].map(([name, color]) => ({ name, color }));

/* ============ utilidades ============ */
const root = document.getElementById('root');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
const reEsc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const fmt = (ts) => new Date(ts).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2));
const areaOf = (id) => AREAS.find((a) => a.id === id);
const wordCount = (t) => (t || '').trim().split(/\s+/).filter(Boolean).length;

const I = {
  lock: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#27466F" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><circle cx="12" cy="16" r="1"/></svg>',
  lockBig: '<svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#27466F" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><circle cx="12" cy="16" r="1"/></svg>',
  eye: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#5A6478" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  shield: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#047857" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l8 3v6c0 4.5-3.4 8.2-8 9-4.6-.8-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/></svg>',
  menu: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#27466F" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M3 6h18M3 12h18M3 18h18"/></svg>',
  plus: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
  plusDark: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#27466F" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
  spark: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4F5FD6" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/></svg>',
  search: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6B7488" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>',
  back: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#27466F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>',
  x: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#27466F" stroke-width="3" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  chev: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#2B3445" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>',
  send: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
  tag: (c) => `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="1.8" stroke-linejoin="round" aria-hidden="true"><path d="M20.6 13.4l-7.2 7.2a2 2 0 0 1-2.8 0L3 13V4h9l8.6 8.6a1 1 0 0 1 0 .8z"/><circle cx="7.5" cy="8.5" r="1"/></svg>`
};

/* ============ estado ============ */
const VAULT_KEY = 'bn.vault';
const NOTE_PREFIX = 'bn.n.';
const SET_KEY = 'bn.settings';

const S = {
  vault: null, DK: null, notes: [], sel: null,
  query: '', tab: 'all', areaF: '', tagF: '',
  view: 'list', drawer: false, chatOpen: false, areasOpen: true, tagsOpen: true,
  chat: [], confirmDel: null, modal: null, setup: null, lockMode: 'pw', err: '', showPw: false,
  settings: { autolock: 2 }, lockTimer: null, saveTimer: null, pending: null
};

const readJSON = (k) => { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } };

/* ============ persistência (sempre criptografada) ============ */
async function persistNote(n) {
  const { iv, ct } = await C.encryptJSON(S.DK, n);
  localStorage.setItem(NOTE_PREFIX + n.id, JSON.stringify({ id: n.id, iv, ct, u: n.updated }));
}
async function loadNotes() {
  const out = [];
  for (const k of Object.keys(localStorage)) {
    if (!k.startsWith(NOTE_PREFIX)) continue;
    try { out.push(await C.decryptJSON(S.DK, JSON.parse(localStorage.getItem(k)))); } catch (e) { /* registro ilegível é ignorado */ }
  }
  return out.sort((a, b) => b.updated - a.updated);
}
const saveVault = () => localStorage.setItem(VAULT_KEY, JSON.stringify(S.vault));
const saveSettings = () => localStorage.setItem(SET_KEY, JSON.stringify(S.settings));

/* ============ bloqueio automático ============ */
function armLock() {
  clearTimeout(S.lockTimer);
  if (!S.DK || !S.settings.autolock) return;
  S.lockTimer = setTimeout(lock, S.settings.autolock * 60000);
}
['pointerdown', 'keydown', 'touchstart'].forEach((ev) => window.addEventListener(ev, armLock, { passive: true }));

function lock() {
  clearTimeout(S.lockTimer);
  if (S.DK && S.pending) { const n = S.pending; S.pending = null; persistNote(n); }
  clearTimeout(S.saveTimer);
  S.DK = null; S.notes = []; S.sel = null; S.modal = null; S.chat = [];
  S.query = ''; S.tab = 'all'; S.areaF = ''; S.tagF = ''; S.view = 'list'; S.drawer = false; S.chatOpen = false;
  S.lockMode = 'pw'; S.err = '';
  render();
}

async function enter(DK) {
  S.DK = DK;
  S.notes = await loadNotes();
  S.sel = S.notes.length ? S.notes[0].id : null;
  S.chat = [{ role: 'a', text: 'Olá, Carlos. Diga o que quer organizar: criar notas, mover entre áreas, adicionar etiquetas, arquivar ou pedir uma visão geral. Digite "ajuda" para ver exemplos.' }];
  S.err = '';
  armLock();
  render();
}

/* ============ telas de entrada ============ */
function pwField(id, label, ph, auto) {
  return `<div class="field"><label for="${id}">${label}</label>
    <div class="pw"><input class="input" id="${id}" type="${S.showPw ? 'text' : 'password'}" placeholder="${ph}" autocomplete="${auto}" required>
    <button type="button" data-act="showpw" aria-label="${S.showPw ? 'Ocultar senha' : 'Mostrar senha'}">${I.eye}</button></div></div>`;
}

function renderSetup() {
  const st = S.setup || (S.setup = { step: 1 });
  if (st.step === 1) {
    return `<div class="gate"><form class="card" id="f-setup" autocomplete="off">
      <div><div class="kicker">Primeiro acesso</div><h1 class="title">Criar seu cofre</h1>
      <p class="sub">A senha mestra protege todas as notas neste aparelho. Ela nunca é enviada para lugar nenhum.</p></div>
      <div class="stack">
        ${pwField('pw1', 'Senha mestra *', 'Mínimo de 12 caracteres', 'new-password')}
        <div class="field"><label for="pw2">Confirmar senha *</label>
          <input class="input" id="pw2" type="${S.showPw ? 'text' : 'password'}" placeholder="Repita a senha mestra" autocomplete="new-password" required></div>
        <span class="hint" style="font-size:13px;color:var(--muted)">Dica: uma frase longa é mais forte e mais fácil de lembrar.</span>
        <div class="err" role="alert">${esc(S.err)}</div>
        <button class="btn" type="submit" id="btn-create">Continuar</button>
      </div>
      <label class="link" style="cursor:pointer">Já tenho uma cópia do cofre
        <input type="file" id="restore" accept="application/json,.json" class="sr"></label>
    </form></div>`;
  }
  return `<div class="gate"><div class="card">
    <div><div class="kicker">Passo final</div><h1 class="title">Guarde sua chave de recuperação</h1>
    <p class="sub">Se você esquecer a senha mestra, esta chave é a <strong>única</strong> forma de recuperar as notas. Ela aparece só agora. Anote ou imprima e guarde fora do computador.</p></div>
    <div class="rk"><code id="rk-code">${esc(st.recovery)}</code>
      <div class="row"><button class="btn small ghost" type="button" data-act="copyrk">Copiar</button>
      <button class="btn small ghost" type="button" data-act="dlrk">Baixar .txt</button></div></div>
    <label class="check"><input type="checkbox" id="rk-ok"><span>Guardei a chave de recuperação em um lugar seguro.</span></label>
    <button class="btn" type="button" id="btn-finish" data-act="finish" disabled>Criar cofre</button>
  </div></div>`;
}

function renderLock() {
  const rec = S.lockMode === 'rk';
  return `<div class="gate"><form class="card" id="f-lock">
    <div class="hero"><span class="badge">${I.lockBig}</span>
      <div><div class="logo">Bloco<span>Notas</span></div><div class="sub">Seu cofre está trancado</div></div></div>
    ${rec
      ? `<div class="stack">
          <div class="field"><label for="rk">Chave de recuperação *</label>
            <input class="input" id="rk" type="text" placeholder="XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX" autocomplete="off" autocapitalize="characters" spellcheck="false" required></div>
          ${pwField('pwn', 'Nova senha mestra *', 'Mínimo de 12 caracteres', 'new-password')}
          <div class="err" role="alert">${esc(S.err)}</div>
          <button class="btn" type="submit">Recuperar e entrar</button></div>
        <button class="link" type="button" data-act="lockmode" data-mode="pw">Voltar para a senha</button>`
      : `<div class="stack">
          ${pwField('pw', 'Senha mestra *', 'Digite sua senha mestra', 'current-password')}
          <div class="err" role="alert">${esc(S.err)}</div>
          <button class="btn" type="submit" id="btn-unlock">Desbloquear</button></div>
        <button class="link" type="button" data-act="lockmode" data-mode="rk">Usar chave de recuperação</button>`}
    <div class="note-box">${I.shield}<span>Suas notas são criptografadas neste aparelho. Sem a senha mestra, ninguém consegue lê-las, nem o servidor.</span></div>
  </form></div>`;
}

/* ============ aplicativo ============ */
function filtered() {
  const q = norm(S.query).trim();
  const byTab = (n) => (S.tab === 'all' ? !n.archived : S.tab === 'pinned' ? n.pinned && !n.archived : n.archived);
  return S.notes.filter((n) => {
    if (!byTab(n)) return false;
    if (S.areaF && n.area !== S.areaF) return false;
    if (S.tagF && !n.tags.includes(S.tagF)) return false;
    if (!q) return true;
    const a = areaOf(n.area);
    return norm(`${n.title} ${n.body} ${n.tags.map((t) => '#' + t).join(' ')} ${a ? a.name : ''}`).includes(q);
  });
}
const current = () => S.notes.find((n) => n.id === S.sel) || null;

function renderApp() {
  return `<div class="shell" id="shell">
    <aside class="side" id="side" aria-label="Áreas e etiquetas"></aside>
    <div class="backdrop" data-act="drawer"></div>
    <section class="listcol" aria-label="Notas">
      <div class="lhead">
        <div class="top">
          <button class="icon-btn plain" data-act="drawer" aria-label="Abrir áreas e etiquetas">${I.menu}</button>
          <h1>Minhas notas</h1>
          <button class="icon-btn" data-act="chat" aria-label="Assistente">${I.spark}</button>
          <button class="icon-btn" data-act="lock" aria-label="Trancar cofre">${I.lock}</button>
        </div>
        <div class="search">${I.search}<label class="sr" for="q">Buscar</label>
          <input id="q" type="search" placeholder="Texto, #etiqueta ou área" value="${esc(S.query)}" autocomplete="off"></div>
        <div class="tabs" id="tabs" role="group" aria-label="Situação"></div>
        <div class="afilters" id="afilters"></div>
        <button class="btn" data-act="new">${I.plus} Nova nota</button>
      </div>
      <ul class="list" id="list"></ul>
      <div class="lfoot" id="lfoot"></div>
    </section>
    <section class="editor" id="editor" aria-label="Editor"></section>
    <aside class="chat" id="chat" aria-label="Assistente de clareza"></aside>
  </div><div id="modal-root"></div>`;
}

function setShell() {
  const sh = document.getElementById('shell');
  if (!sh) return;
  sh.className = 'shell' + (S.view === 'editor' ? ' show-editor' : '') + (S.drawer ? ' drawer-open' : '') + (S.chatOpen ? ' chat-open' : '');
}

function renderSide() {
  const el = document.getElementById('side');
  if (!el) return;
  const live = S.notes;
  el.innerHTML = `<div class="brand">Bloco<span>Notas</span></div>
    <button class="sec" data-act="sec" data-sec="areas" aria-expanded="${S.areasOpen}">${I.chev}<span>Áreas</span></button>
    ${S.areasOpen ? AREAS.map((a) => `<button class="opt" data-act="area" data-id="${a.id}" aria-pressed="${S.areaF === a.id}">
      <span class="dot" style="background:${a.color}"></span><span class="nm">${esc(a.name)}</span>
      <span class="n">${live.filter((n) => n.area === a.id).length || ''}</span></button>`).join('') : ''}
    <button class="sec" data-act="sec" data-sec="tags" aria-expanded="${S.tagsOpen}">${I.chev}<span>Etiquetas</span></button>
    ${S.tagsOpen ? TAGS.map((t) => `<button class="opt" data-act="tag" data-id="${esc(t.name)}" aria-pressed="${S.tagF === t.name}">
      ${I.tag(t.color)}<span class="nm">${esc(t.name)}</span>
      <span class="n">${live.filter((n) => n.tags.includes(t.name)).length || ''}</span></button>`).join('') : ''}
    <div class="side-foot">
      <button class="btn small ghost" data-act="settings">Configurações</button>
      <button class="btn small ghost" data-act="lock">Trancar cofre</button>
    </div>`;
}

function renderFilters() {
  const t = document.getElementById('tabs');
  if (!t) return;
  const cnt = {
    all: S.notes.filter((n) => !n.archived).length,
    pinned: S.notes.filter((n) => n.pinned && !n.archived).length,
    archived: S.notes.filter((n) => n.archived).length
  };
  t.innerHTML = [['all', 'Todas'], ['pinned', 'Fixadas'], ['archived', 'Arquivadas']].map(([id, lb]) =>
    `<button class="tab" data-act="tab" data-id="${id}" aria-pressed="${S.tab === id}">${lb}<span class="pill">${cnt[id]}</span></button>`).join('');
  const f = [];
  if (S.areaF) f.push(`<button class="chip" data-act="clear-area" aria-label="Remover filtro de área">${esc(areaOf(S.areaF).name)} ${I.x}</button>`);
  if (S.tagF) f.push(`<button class="chip" data-act="clear-tag" aria-label="Remover filtro de etiqueta">#${esc(S.tagF)} ${I.x}</button>`);
  document.getElementById('afilters').innerHTML = f.join('');
}

function renderList() {
  const ul = document.getElementById('list');
  if (!ul) return;
  const items = filtered();
  ul.innerHTML = items.length ? items.map((n) => {
    const a = areaOf(n.area);
    const badge = n.archived ? '<span class="badge arc">Arquivada</span>' : n.pinned ? '<span class="badge pin">Fixada</span>' : '<span class="badge">Ativa</span>';
    return `<li><button class="item" data-act="open" data-id="${n.id}" aria-current="${n.id === S.sel}">
      <span class="col"><span class="ti">${esc(n.title || 'Sem título')}</span>
      <span class="pv">${esc((n.body || 'Nota vazia').split('\n')[0])}</span>
      <span class="meta"><span class="dot" style="width:8px;height:8px;background:${a ? a.color : '#A9B4C6'}"></span>${esc(a ? a.name : 'Sem área')} · ${fmt(n.updated)}</span>
      ${n.tags.length ? `<span class="tg">${n.tags.map((t) => '#' + esc(t)).join(' ')}</span>` : ''}</span>${badge}</button></li>`;
  }).join('') : `<li class="empty">${S.notes.length ? 'Nenhuma nota encontrada com esses filtros.' : 'Seu cofre está vazio. Toque em "Nova nota" ou peça ao assistente: "crie uma nota Ideias na área Metas".'}</li>`;
  document.getElementById('lfoot').textContent = `Mostrando ${items.length} de ${S.notes.length}`;
}

function renderEditor() {
  const el = document.getElementById('editor');
  if (!el) return;
  const n = current();
  if (!n) {
    el.innerHTML = `<div class="ed-top"><button class="btn small ghost back" data-act="back" aria-label="Voltar">${I.back}<span class="bt"> Voltar</span></button></div>
      <div class="ed-empty"><div>Selecione uma nota ou crie uma nova.</div><button class="btn" data-act="new">${I.plus} Nova nota</button></div>`;
    return;
  }
  const addable = TAGS.filter((t) => !n.tags.includes(t.name));
  el.innerHTML = `<div class="ed-top">
      <button class="btn small ghost back" data-act="back" aria-label="Voltar">${I.back}<span class="bt"> Voltar</span></button><span class="sp"></span>
      <button class="btn small ghost" data-act="pin">${n.pinned ? 'Desafixar' : 'Fixar'}</button>
      <button class="btn small ghost" data-act="archive">${n.archived ? 'Restaurar' : 'Arquivar'}</button>
      <button class="btn small danger" data-act="del">${S.confirmDel === n.id ? 'Confirmar exclusão' : 'Excluir'}</button>
    </div>
    <div class="ed-body">
      <label class="sr" for="t">Título da nota</label>
      <input class="ed-title" id="t" type="text" value="${esc(n.title)}" placeholder="Sem título" autocomplete="off">
      <div class="ed-meta" id="ed-meta">${fmt(n.updated)} · ${wordCount(n.body)} palavras</div>
      <div class="ed-tags">
        <label class="sr" for="area">Área</label>
        <select class="sel" id="area"><option value="">Sem área</option>${AREAS.map((a) => `<option value="${a.id}" ${n.area === a.id ? 'selected' : ''}>${esc(a.name)}</option>`).join('')}</select>
        ${n.tags.map((t) => `<span class="chip">#${esc(t)}<button data-act="rmtag" data-id="${esc(t)}" aria-label="Remover etiqueta ${esc(t)}">${I.x}</button></span>`).join('')}
        <label class="sr" for="addtag">Adicionar etiqueta</label>
        <select class="sel add" id="addtag"><option value="">+ Etiqueta</option>${addable.map((t) => `<option value="${esc(t.name)}">#${esc(t.name)}</option>`).join('')}</select>
      </div>
      <label class="sr" for="b">Texto da nota</label>
      <textarea class="paper" id="b" placeholder="Comece a escrever…">${esc(n.body)}</textarea>
    </div>`;
}

function renderChat() {
  const el = document.getElementById('chat');
  if (!el) return;
  el.innerHTML = `<div class="ch">${I.spark}<span>Assistente de clareza</span>
      <button class="icon-btn plain" data-act="chat" aria-label="Fechar assistente">${I.x}</button></div>
    <div class="msgs" id="msgs" role="log" aria-live="polite">${S.chat.map((m) => `<div class="m ${m.role === 'u' ? 'me' : ''}">${esc(m.text)}</div>`).join('')}</div>
    <div class="sugg">${['Visão geral das notas', 'Limpar filtros', 'Ajuda'].map((s) => `<button data-act="sugg" data-text="${esc(s)}">${esc(s)}</button>`).join('')}</div>
    <form class="cform" id="f-chat" autocomplete="off"><label class="sr" for="cm">Mensagem</label>
      <input id="cm" type="text" placeholder="Fale com o assistente" enterkeyhint="send"><button type="submit" aria-label="Enviar">${I.send}</button></form>`;
  const m = document.getElementById('msgs');
  if (m) m.scrollTop = m.scrollHeight;
}

function renderModal() {
  const el = document.getElementById('modal-root');
  if (!el) return;
  if (!S.modal) { el.innerHTML = ''; return; }
  const m = S.modal;
  el.innerHTML = `<div class="modal-bg" data-act="modal-bg"><div class="modal" role="dialog" aria-modal="true" aria-label="Configurações do cofre">
    <div class="mh">Configurações do cofre<button class="icon-btn plain" data-act="modal-close" aria-label="Fechar">${I.x}</button></div>
    <div class="mb">
      <section><h3>Segurança</h3>
        <div class="field"><label for="al">Trancar automaticamente</label>
          <select class="sel" id="al" style="max-width:none">${[[1, 'Após 1 minuto'], [2, 'Após 2 minutos'], [5, 'Após 5 minutos'], [15, 'Após 15 minutos'], [0, 'Nunca']].map(([v, l]) => `<option value="${v}" ${S.settings.autolock === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      </section>
      <section><h3>Trocar senha mestra</h3>
        <form class="stack" id="f-chpw">
          <div class="field"><label for="cp0">Senha atual</label><input class="input" id="cp0" type="password" autocomplete="current-password" required></div>
          <div class="field"><label for="cp1">Nova senha (mínimo 12 caracteres)</label><input class="input" id="cp1" type="password" autocomplete="new-password" required></div>
          <div class="field"><label for="cp2">Confirmar nova senha</label><input class="input" id="cp2" type="password" autocomplete="new-password" required></div>
          <div class="err" role="alert">${esc(m.errPw || '')}</div>${m.okPw ? `<div class="msg-ok">${esc(m.okPw)}</div>` : ''}
          <button class="btn small" type="submit">Trocar senha</button></form>
      </section>
      <section><h3>Chave de recuperação</h3>
        ${m.newRk ? `<div class="rk"><code>${esc(m.newRk)}</code><span class="sub" style="font-size:14px">Anote agora. A chave anterior deixou de funcionar e esta não será exibida de novo.</span>
          <div class="row"><button class="btn small ghost" data-act="copyrk2">Copiar</button></div></div>`
          : `<p class="sub" style="margin:0 0 10px;font-size:14px">A chave atual não pode ser exibida de novo. Você pode gerar uma nova, que substitui a anterior.</p>
             <button class="btn small ghost" data-act="newrk">Gerar nova chave</button>`}
      </section>
      <section><h3>Backup</h3>
        <p class="sub" style="margin:0 0 10px;font-size:14px">A cópia contém apenas dados criptografados. Para restaurar em outro aparelho, use "Já tenho uma cópia do cofre" na tela de criação.</p>
        <button class="btn small ghost" data-act="export">Exportar cópia criptografada</button>
      </section>
      <section><h3>Zona de risco</h3>
        <button class="btn small danger" data-act="wipe">${m.wipe ? 'Confirmar: apagar tudo neste aparelho' : 'Apagar cofre neste aparelho'}</button>
      </section>
    </div></div></div>`;
}

function renderAll() {
  setShell(); renderSide(); renderFilters(); renderList(); renderEditor(); renderChat(); renderModal();
}

function render() {
  if (!S.vault) root.innerHTML = renderSetup();
  else if (!S.DK) root.innerHTML = renderLock();
  else { root.innerHTML = renderApp(); renderAll(); }
  const f = root.querySelector('input.input, #q');
  if (f && !S.DK) f.focus();
}

/* ============ ações sobre notas ============ */
function touch(n, patch) {
  Object.assign(n, patch, { updated: Date.now() });
  persistNote(n);
}
function newNote(init = {}) {
  const n = { id: uid(), title: '', body: '', area: S.areaF || '', tags: S.tagF ? [S.tagF] : [], pinned: false, archived: false, created: Date.now(), updated: Date.now(), ...init };
  S.notes.unshift(n);
  persistNote(n);
  return n;
}
function flushSave() {
  clearTimeout(S.saveTimer);
  if (!S.pending) return;
  const n = S.pending;
  S.pending = null;
  persistNote(n);
  renderList(); renderSide(); renderFilters();
}
function scheduleSave(n) {
  n.updated = Date.now();
  S.pending = n;
  clearTimeout(S.saveTimer);
  S.saveTimer = setTimeout(flushSave, 500);
}

/* ============ assistente (comandos em português) ============ */
function areaFromText(t) {
  const m = t.match(/area\s*(\d{1,2})\b/);
  if (m && areaOf(String(Number(m[1])))) return String(Number(m[1]));
  const keys = { 1: ['espiritual', 'proposito'], 2: ['profissional', 'carreira'], 3: ['financeiro', 'negocios', 'investimentos'], 4: ['sentimental', 'relacionamentos', 'relacionamento'], 5: ['saude', 'fitness', 'bem-estar', 'bem estar'], 6: ['familia', 'amigos', 'social'], 7: ['mentalidade', 'intelectual', 'desenvolvimento'], 8: ['estudos', 'cursos', 'treinamentos'], 9: ['hobbies', 'lazer', 'leitura', 'podcasts'], 10: ['metas', 'sonhos', 'objetivos'], 11: ['ambiente', 'organizacao', 'minimalismo'], 12: ['tecnologia', 'sistemas', 'ferramentas', 'automacao'], 13: ['autoimagem', 'identidade', 'estilo'] };
  for (const id in keys) if (keys[id].some((k) => new RegExp('(^|[^a-z0-9])' + reEsc(k) + '($|[^a-z0-9])').test(t))) return id;
  return '';
}
function tagsFromText(t, needHash) {
  return TAGS.map((d) => d.name).filter((name) => {
    const k = reEsc(norm(name));
    return (needHash ? new RegExp('#' + k + '($|[^a-z0-9])') : new RegExp('(^|[^a-z0-9])#?' + k + '($|[^a-z0-9])')).test(t);
  });
}
function parse(text) {
  const t = norm(text).trim();
  const cut = (s) => s.replace(/\s+(?:na\s+área|na\s+area|em\s+área|em\s+area|área|area|com\s+(?:a\s+)?etiquetas?|com\s+#|#).*$/i, '').trim();
  if (/^(ajuda|help)\b|o que (voce|vc) (faz|pode)/.test(t)) return [{ type: 'help' }];
  if (/limpar (os )?filtros|remover (os )?filtros|mostrar tudo/.test(t)) return [{ type: 'clearFilters' }];
  if (/visao geral|resum|clareza|panorama|o que tenho|sem area/.test(t)) return [{ type: 'overview' }];
  let m = text.match(/^\s*(?:criar|crie|nova|novo|adicionar|adicione|anotar|anote)\b.*?\bnota\b(?:\s+(?:sobre|chamada|intitulada|com\s+t[ií]tulo))?\s*:?\s*(.+)$/i);
  if (m && /etiquet|\btag\b/.test(norm(text.slice(0, text.search(/\bnota\b/i))))) m = null;
  if (m) {
    const rest = m[1];
    const title = cut(rest);
    const after = norm(rest.slice(title.length));
    const tags = tagsFromText(after, true).concat(/etiquetas?/.test(after) ? tagsFromText(after.replace(/.*etiquetas?/, ''), false) : []);
    return [{ type: 'createNote', title: title.charAt(0).toUpperCase() + title.slice(1), area: areaFromText(after), tags: [...new Set(tags)] }];
  }
  if (/^(buscar|busque|procure|pesquise|pesquisar|mostrar|mostre|filtrar|filtre)\b/.test(t)) {
    const rest = t.replace(/^\S+\s+/, '').replace(/^(as\s+)?notas\s+(sobre|de|da|do|com)\s+/, '');
    const tg = tagsFromText(rest, false);
    if (tg.length) return [{ type: 'filterTag', tag: tg[0] }];
    const ar = areaFromText(rest);
    if (ar) return [{ type: 'filterArea', area: ar }];
    return [{ type: 'search', query: rest }];
  }
  const noteTarget = (s) => { const x = s.match(/nota\s+(?:chamada\s+|de\s+)?(.+)$/); return x ? x[1].trim() : ''; };
  if (/(desafix|desprend)/.test(t)) return [{ type: 'unpin', target: noteTarget(t) }];
  if (/(desarquiv|restaur)/.test(t)) return [{ type: 'restore', target: noteTarget(t) }];
  if (/(arquiv)/.test(t)) return [{ type: 'archive', target: noteTarget(t) }];
  if (/\b(fixar|fixe|fixa)\b/.test(t)) return [{ type: 'pin', target: noteTarget(t) }];
  const tags = tagsFromText(t, false);
  const cleanTarget = (g) => { let target = noteTarget(t); tags.forEach((x) => { target = target.replace(new RegExp('#?' + reEsc(norm(x)), 'g'), ''); }); return target.replace(/\b(a|de|da|do|etiqueta|etiquetas|tag)\b/g, '').trim(); };
  if (tags.length && /(remov|tire|tirar|apag|delet)/.test(t)) return tags.map((g) => ({ type: 'removeTag', tag: g, target: cleanTarget() }));
  if (tags.length && /(adicion|coloc|ponh|marc|etiquet|tag|#)/.test(t)) return tags.map((g) => ({ type: 'addTag', tag: g, target: cleanTarget() }));
  m = t.match(/\b(?:mover|mova|move|passar|passe|trocar|troque|classificar|classifique|colocar|coloque|ponha)\b(.*?)\b(?:para|pra|na|em)\b\s*(?:a\s+)?(?:area\s*)?(.+)$/);
  if (m) {
    const ar = areaFromText(m[2]);
    if (ar) return [{ type: 'moveArea', area: ar, target: m[1].replace(/\b(a|essa|esta|nota)\b/g, '').trim() }];
  }
  return [{ type: 'unknown' }];
}
function findNote(target) {
  const tt = norm(target).trim();
  if (!tt) return current();
  let best = null;
  S.notes.forEach((n) => { const nt = norm(n.title); if (nt && (tt.includes(nt) || nt.includes(tt)) && (!best || nt.length > norm(best.title).length)) best = n; });
  return best;
}
function applyActions(actions) {
  const out = [];
  const tagCanon = (g) => TAGS.map((x) => x.name).find((x) => norm(x) === norm(g));
  actions.forEach((a) => {
    if (a.type === 'help') return out.push('Exemplos do que posso fazer:\n• "criar nota Ideias de vídeo na área Profissional com #Planner"\n• "mover Pensamentos para área Espiritual"\n• "adicionar etiqueta Fit na nota Leituras"\n• "arquivar a nota Para lembrar"\n• "buscar #Mindset" ou "buscar tecnologia"\n• "visão geral" para ver como estão suas notas');
    if (a.type === 'clearFilters') { S.query = ''; S.areaF = ''; S.tagF = ''; S.tab = 'all'; const q = document.getElementById('q'); if (q) q.value = ''; return out.push('Filtros limpos. Mostrando todas as notas ativas.'); }
    if (a.type === 'search') { S.query = a.query || ''; S.tab = 'all'; const q = document.getElementById('q'); if (q) q.value = S.query; return out.push(`Buscando por "${a.query}".`); }
    if (a.type === 'filterTag') { const g = tagCanon(a.tag); if (!g) return out.push(`Não conheço a etiqueta "${a.tag}".`); S.tagF = g; S.tab = 'all'; return out.push(`Filtrando pela etiqueta #${g}.`); }
    if (a.type === 'filterArea') { const ar = areaOf(String(a.area)); if (!ar) return out.push('Não encontrei essa área.'); S.areaF = ar.id; S.tab = 'all'; return out.push(`Filtrando pela área ${ar.name}.`); }
    if (a.type === 'overview') {
      const live = S.notes.filter((n) => !n.archived);
      const L = [`Você tem ${live.length} ${live.length === 1 ? 'nota ativa' : 'notas ativas'}, ${live.filter((n) => n.pinned).length} fixada(s) e ${S.notes.filter((n) => n.archived).length} arquivada(s).`];
      const by = AREAS.map((x) => ({ x, c: live.filter((n) => n.area === x.id).length })).filter((r) => r.c);
      if (by.length) L.push('Por área: ' + by.map((r) => `${r.x.name} (${r.c})`).join(', ') + '.');
      const na = live.filter((n) => !n.area); if (na.length) L.push('Sem área: ' + na.map((n) => n.title || 'Sem título').join(', ') + '. Diga "mover [nota] para área ..." para classificar.');
      const em = live.filter((n) => !(n.body || '').trim()); if (em.length) L.push('Sem texto: ' + em.map((n) => n.title || 'Sem título').join(', ') + '.');
      const nt = live.filter((n) => !n.tags.length); if (nt.length) L.push('Sem etiqueta: ' + nt.map((n) => n.title || 'Sem título').join(', ') + '.');
      const free = AREAS.filter((x) => !live.some((n) => n.area === x.id)); if (free.length && live.length) L.push('Áreas sem nenhuma nota: ' + free.map((x) => x.name).join(', ') + '.');
      return out.push(L.join('\n'));
    }
    if (a.type === 'unknown') return out.push('Não entendi esse pedido. Digite "ajuda" para ver exemplos do que consigo fazer.');
    if (a.type === 'createNote') {
      const title = (a.title || '').trim();
      if (!title) return out.push('Qual deve ser o título da nota?');
      const ar = areaOf(String(a.area));
      const tgs = (a.tags || []).map(tagCanon).filter(Boolean);
      const n = newNote({ title, area: ar ? ar.id : '', tags: tgs });
      S.sel = n.id; S.tab = 'all'; S.query = ''; S.areaF = ''; S.tagF = '';
      const q = document.getElementById('q'); if (q) q.value = '';
      return out.push(`Nota "${title}" criada${ar ? ' na área ' + ar.name : ''}${tgs.length ? ' com ' + tgs.map((g) => '#' + g).join(' ') : ''}. Ela já está aberta no editor.`);
    }
    const n = findNote(a.target || '');
    if (!n) return out.push(`Não encontrei a nota "${a.target || ''}".`);
    const nm = n.title || 'Sem título';
    if (a.type === 'moveArea') { const ar = areaOf(String(a.area)); if (!ar) return out.push('Não encontrei essa área.'); touch(n, { area: ar.id }); return out.push(`"${nm}" agora está na área ${ar.name}.`); }
    if (a.type === 'addTag') { const g = tagCanon(a.tag); if (!g) return out.push(`Não conheço a etiqueta "${a.tag}".`); if (!n.tags.includes(g)) touch(n, { tags: [...n.tags, g] }); return out.push(`#${g} adicionada em "${nm}".`); }
    if (a.type === 'removeTag') { const g = tagCanon(a.tag); if (!g) return out.push(`Não conheço a etiqueta "${a.tag}".`); touch(n, { tags: n.tags.filter((x) => x !== g) }); return out.push(`#${g} removida de "${nm}".`); }
    if (a.type === 'archive') { touch(n, { archived: true }); return out.push(`"${nm}" foi arquivada.`); }
    if (a.type === 'restore') { touch(n, { archived: false }); return out.push(`"${nm}" foi restaurada.`); }
    if (a.type === 'pin') { touch(n, { pinned: true }); return out.push(`"${nm}" foi fixada.`); }
    if (a.type === 'unpin') { touch(n, { pinned: false }); return out.push(`"${nm}" foi desafixada.`); }
    return out.push('Não sei executar essa ação.');
  });
  return out;
}
function ask(raw) {
  const text = (raw || '').trim();
  if (!text) return;
  S.chat.push({ role: 'u', text });
  S.chat.push({ role: 'a', text: applyActions(parse(text)).join('\n') || 'Pronto.' });
  S.chat = S.chat.slice(-40);
  renderSide(); renderFilters(); renderList(); renderEditor(); renderChat();
}

/* ============ eventos ============ */
function download(name, text, type = 'application/json') {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type }));
  a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

root.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-act]');
  if (!b) return;
  const act = b.dataset.act;
  const id = b.dataset.id;
  if (act === 'modal-bg') { if (e.target === b) { S.modal = null; renderModal(); } return; }
  switch (act) {
    case 'showpw': { S.showPw = !S.showPw; const vals = [...root.querySelectorAll('input')].map((i) => i.value); render(); [...root.querySelectorAll('input')].forEach((i, k) => { if (vals[k] !== undefined && i.type !== 'file' && i.type !== 'checkbox') i.value = vals[k]; }); break; }
    case 'lockmode': S.lockMode = b.dataset.mode; S.err = ''; render(); break;
    case 'copyrk': navigator.clipboard && navigator.clipboard.writeText(S.setup.recovery); b.textContent = 'Copiada'; break;
    case 'dlrk': download('chave-de-recuperacao-bloconotas.txt', `BlocoNotas - chave de recuperação\n\n${S.setup.recovery}\n\nGuarde fora do computador. Quem tiver esta chave consegue abrir o cofre.\n`, 'text/plain'); break;
    case 'finish': {
      const st = S.setup;
      S.vault = st.vault; saveVault(); S.setup = null; S.showPw = false;
      await enter(st.DK); break;
    }
    case 'lock': lock(); break;
    case 'drawer': S.drawer = !S.drawer; setShell(); break;
    case 'chat': S.chatOpen = !S.chatOpen; S.drawer = false; setShell(); if (S.chatOpen) { renderChat(); const c = document.getElementById('cm'); if (c) c.focus(); } break;
    case 'sugg': ask(b.dataset.text); break;
    case 'sec': if (b.dataset.sec === 'areas') S.areasOpen = !S.areasOpen; else S.tagsOpen = !S.tagsOpen; renderSide(); break;
    case 'area': S.areaF = S.areaF === id ? '' : id; S.drawer = false; setShell(); renderSide(); renderFilters(); renderList(); break;
    case 'tag': S.tagF = S.tagF === id ? '' : id; S.drawer = false; setShell(); renderSide(); renderFilters(); renderList(); break;
    case 'clear-area': S.areaF = ''; renderSide(); renderFilters(); renderList(); break;
    case 'clear-tag': S.tagF = ''; renderSide(); renderFilters(); renderList(); break;
    case 'tab': S.tab = id; renderFilters(); renderList(); break;
    case 'open': flushSave(); S.sel = id; S.view = 'editor'; S.confirmDel = null; setShell(); renderList(); renderEditor(); break;
    case 'back': flushSave(); S.view = 'list'; setShell(); break;
    case 'new': { const n = newNote(); S.sel = n.id; S.view = 'editor'; S.tab = 'all'; setShell(); renderAll(); const t = document.getElementById('t'); if (t) t.focus(); break; }
    case 'pin': { const n = current(); if (n) { touch(n, { pinned: !n.pinned }); renderEditor(); renderList(); renderFilters(); } break; }
    case 'archive': { const n = current(); if (n) { touch(n, { archived: !n.archived }); renderEditor(); renderList(); renderFilters(); renderSide(); } break; }
    case 'del': {
      const n = current(); if (!n) break;
      if (S.confirmDel !== n.id) { S.confirmDel = n.id; renderEditor(); break; }
      localStorage.removeItem(NOTE_PREFIX + n.id);
      S.notes = S.notes.filter((x) => x.id !== n.id); S.confirmDel = null;
      const next = filtered()[0]; S.sel = next ? next.id : null; S.view = 'list';
      renderAll(); break;
    }
    case 'rmtag': { const n = current(); if (n) { touch(n, { tags: n.tags.filter((t) => t !== id) }); renderEditor(); renderList(); renderSide(); } break; }
    case 'settings': S.modal = {}; S.drawer = false; setShell(); renderModal(); break;
    case 'modal-close': S.modal = null; renderModal(); break;
    case 'newrk': { const r = await C.newRecoveryKey(S.vault, S.DK); S.vault = r.vault; saveVault(); S.modal.newRk = r.recovery; renderModal(); break; }
    case 'copyrk2': navigator.clipboard && navigator.clipboard.writeText(S.modal.newRk); b.textContent = 'Copiada'; break;
    case 'export': {
      const notes = Object.keys(localStorage).filter((k) => k.startsWith(NOTE_PREFIX)).map((k) => JSON.parse(localStorage.getItem(k)));
      download(`bloconotas-copia-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify({ app: 'bloconotas', v: 1, vault: S.vault, notes }));
      break;
    }
    case 'wipe': {
      if (!S.modal.wipe) { S.modal.wipe = true; renderModal(); break; }
      Object.keys(localStorage).filter((k) => k.startsWith('bn.')).forEach((k) => localStorage.removeItem(k));
      S.vault = null; S.DK = null; S.notes = []; S.modal = null; S.setup = null; render(); break;
    }
    default: break;
  }
});

root.addEventListener('input', (e) => {
  const t = e.target;
  if (t.id === 'q') { S.query = t.value; renderList(); return; }
  const n = current();
  if (!n) return;
  if (t.id === 't') { n.title = t.value; scheduleSave(n); }
  if (t.id === 'b') { n.body = t.value; scheduleSave(n); const m = document.getElementById('ed-meta'); if (m) m.textContent = `${fmt(n.updated)} · ${wordCount(n.body)} palavras`; }
  if (t.id === 'rk-ok') { document.getElementById('btn-finish').disabled = !t.checked; }
});

root.addEventListener('change', async (e) => {
  const t = e.target;
  if (t.id === 'rk-ok') { document.getElementById('btn-finish').disabled = !t.checked; return; }
  if (t.id === 'al') { S.settings.autolock = Number(t.value); saveSettings(); armLock(); return; }
  if (t.id === 'restore' && t.files[0]) {
    try {
      const data = JSON.parse(await t.files[0].text());
      if (data.app !== 'bloconotas' || !data.vault) throw new Error('arquivo inválido');
      Object.keys(localStorage).filter((k) => k.startsWith('bn.')).forEach((k) => localStorage.removeItem(k));
      localStorage.setItem(VAULT_KEY, JSON.stringify(data.vault));
      (data.notes || []).forEach((r) => localStorage.setItem(NOTE_PREFIX + r.id, JSON.stringify(r)));
      S.vault = data.vault; S.err = ''; S.lockMode = 'pw'; render();
    } catch (err) { S.err = 'Não foi possível ler essa cópia.'; render(); }
    return;
  }
  const n = current();
  if (!n) return;
  if (t.id === 'area') { touch(n, { area: t.value }); renderList(); renderSide(); }
  if (t.id === 'addtag' && t.value) { touch(n, { tags: [...n.tags, t.value] }); renderEditor(); renderList(); renderSide(); }
});

root.addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = e.target.id;
  if (id === 'f-setup') {
    const p1 = document.getElementById('pw1').value;
    const p2 = document.getElementById('pw2').value;
    if (p1.length < 12) { S.err = 'A senha precisa ter pelo menos 12 caracteres.'; return render(); }
    if (p1 !== p2) { S.err = 'As senhas não conferem.'; return render(); }
    const btn = document.getElementById('btn-create'); btn.disabled = true; btn.textContent = 'Criando…';
    const r = await C.createVault(p1);
    S.err = ''; S.setup = { step: 2, vault: r.vault, DK: r.DK, recovery: r.recovery };
    render();
  } else if (id === 'f-lock') {
    const btn = e.target.querySelector('button[type=submit]'); btn.disabled = true; btn.textContent = 'Verificando…';
    try {
      if (S.lockMode === 'rk') {
        const np = document.getElementById('pwn').value;
        if (np.length < 12) throw new Error('short');
        const DK = await C.unlockWithRecovery(S.vault, document.getElementById('rk').value);
        S.vault = await C.rewrapPassword(S.vault, DK, np); saveVault();
        S.showPw = false; await enter(DK);
      } else {
        const DK = await C.unlockWithPassword(S.vault, document.getElementById('pw').value);
        S.showPw = false; await enter(DK);
      }
    } catch (err) {
      S.err = err.message === 'short' ? 'A nova senha precisa ter pelo menos 12 caracteres.' : S.lockMode === 'rk' ? 'Chave de recuperação incorreta.' : 'Senha incorreta.';
      render();
    }
  } else if (id === 'f-chat') {
    const i = document.getElementById('cm'); const v = i.value; i.value = ''; ask(v);
    const c = document.getElementById('cm'); if (c) c.focus();
  } else if (id === 'f-chpw') {
    const m = S.modal;
    const [a, b, c] = ['cp0', 'cp1', 'cp2'].map((x) => document.getElementById(x).value);
    m.okPw = ''; m.errPw = '';
    try { await C.unlockWithPassword(S.vault, a); } catch (err) { m.errPw = 'A senha atual está incorreta.'; return renderModal(); }
    if (b.length < 12) { m.errPw = 'A nova senha precisa ter pelo menos 12 caracteres.'; return renderModal(); }
    if (b !== c) { m.errPw = 'As senhas novas não conferem.'; return renderModal(); }
    S.vault = await C.rewrapPassword(S.vault, S.DK, b); saveVault();
    m.okPw = 'Senha trocada com sucesso.'; renderModal();
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && S.modal) { S.modal = null; renderModal(); }
});

/* ============ início ============ */
S.vault = readJSON(VAULT_KEY);
S.settings = Object.assign(S.settings, readJSON(SET_KEY) || {});
render();
if ('serviceWorker' in navigator && location.protocol !== 'file:') navigator.serviceWorker.register('sw.js').catch(() => {});
